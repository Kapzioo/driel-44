#Volumetric Particle Flow

![Alt text](http://david.li/images/flowgithub.png)

[http://david.li/flow](http://david.li/flow) ([video](http://www.youtube.com/watch?v=a0hJAZfIRvE))

WebGL + curl noise + half-angle slice rendering + incremental odd-even merge sort