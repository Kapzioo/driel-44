The application is a 3D-model renderer using particles (Imported via CDNJS). 
This application is made using *HTML* , *CSS*, *JavaScript* , *THREE JS*.

To open the application, visit this link::

https://melodious-smakager-b32f2d.netlify.app

Or, download the code and open *index.html* in any browser.
